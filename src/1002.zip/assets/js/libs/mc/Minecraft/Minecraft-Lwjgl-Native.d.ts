/**
 * @author Luuxis
 * @license CC-BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
 */
export default class MinecraftLoader {
    options: any;
    constructor(options: any);
    ProcessJson(version: any): Promise<any>;
}
