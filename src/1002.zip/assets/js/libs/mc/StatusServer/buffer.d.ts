declare function CustomBuffer(existingBuffer?: any): void;
export default CustomBuffer;
